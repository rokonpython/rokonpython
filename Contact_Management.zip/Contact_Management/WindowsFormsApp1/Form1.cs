﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {       
        SqlCommand cmd = new SqlCommand();       

        public Form1()
        {
            InitializeComponent();
        }

        private void btn_login_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=D:\\Testing_Projects\\Contact_Management\\database.mdf;Integrated Security=True;Connect Timeout=30";
            SqlDataAdapter adapter = new SqlDataAdapter("Select Count (*) From Login where username='" + txtUsername.Text+ "' and password ='" + txtPassword.Text+ "'",con);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            if(dt.Rows[0][0].ToString() == "1")
            {
                this.Hide();
                home main = new home();
                main.Show();
            }
            else
            {
                MessageBox.Show("Please Check Your Login Details");
            }
        }
    }
}
